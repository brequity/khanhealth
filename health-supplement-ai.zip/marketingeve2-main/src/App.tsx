import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import SearchBar from './components/SearchBar';
import MainContent from './components/MainContent';
import { getCompletion } from './services/openai';
import { getErrorMessage } from './utils/errors';

export default function App() {
  const [response, setResponse] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const handleAskQuestion = async (question: string) => {
    setIsLoading(true);
    setError(null);
    setResponse(null);
    
    try {
      const response = await getCompletion(question);
      setResponse(response);
    } catch (err) {
      const errorMessage = getErrorMessage(err);
      setError(errorMessage);
      console.error('Error getting response:', errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setResponse(null);
    setError(null);
    setIsLoading(false);
  };

  return (
    <div className="flex h-screen bg-white text-gray-900 transition-colors">
      <Sidebar 
        isOpen={isSidebarOpen} 
        onToggle={toggleSidebar} 
        onHomeClick={handleReset}
      />
      <main className="flex-1 flex flex-col h-screen relative">
        <div className="flex-1 overflow-auto">
          <div className="max-w-3xl mx-auto px-4 py-6">
            <MainContent 
              response={response}
              error={error}
              onAskQuestion={handleAskQuestion}
              isLoading={isLoading}
            />
          </div>
        </div>
        <div className="border-t border-gray-200 bg-white">
          <div className="max-w-3xl mx-auto px-4 py-4">
            <SearchBar 
              onResponse={setResponse}
              isLoading={isLoading}
            />
          </div>
        </div>
      </main>
    </div>
  );
}