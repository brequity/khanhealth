import React from 'react';
import { Search, Sparkles } from 'lucide-react';

export default function FollowUpInput() {
  return (
    <div className="sticky bottom-4">
      <div className="relative">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-primary-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-12 pr-24 py-3 bg-gray-50 border border-primary-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
          placeholder="Ask follow up..."
        />
        <div className="absolute inset-y-0 right-4 flex items-center gap-2">
          <span className="text-xs text-white bg-primary-500 px-2 py-1 rounded flex items-center gap-1">
            <Sparkles size={12} />
            Pro
          </span>
        </div>
      </div>
    </div>
  );
}