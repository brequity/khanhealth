import React from 'react';
import { Sparkles } from 'lucide-react';
import MarketingCard from './marketing/MarketingCard';
import { marketingCards } from '../data/marketingCards';

interface WelcomeMessageProps {
  onAskQuestion: (question: string) => void;
}

export default function WelcomeMessage({ onAskQuestion }: WelcomeMessageProps) {
  const handleCardClick = (query: string) => {
    if (onAskQuestion) {
      onAskQuestion(query);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] text-center px-4">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles className="w-6 h-6 text-primary-500" />
        <h1 className="text-2xl font-semibold text-gray-900">
          Marketing Eve
        </h1>
      </div>
      <p className="text-lg text-gray-600 mb-6 max-w-xl">
        How can I help you with Xiaohongshu marketing today?
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-2xl w-full">
        {marketingCards.map((card) => (
          <MarketingCard
            key={card.id}
            title={card.title}
            description={card.description}
            onClick={() => handleCardClick(card.query)}
          />
        ))}
      </div>
    </div>
  );
}