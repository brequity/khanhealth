import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { getCompletion } from '../services/openai';
import { getErrorMessage } from '../utils/errors';
import LoadingSpinner from './ui/LoadingSpinner';

interface SearchBarProps {
  onResponse: (response: string) => void;
  isLoading?: boolean;
}

export default function SearchBar({ onResponse, isLoading: parentIsLoading }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || isLoading || parentIsLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await getCompletion(query);
      onResponse(response);
      setQuery('');
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative">
      <div className="relative flex items-center">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full rounded-lg border border-gray-200 bg-white pl-4 pr-12 py-3 shadow-lg focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
          placeholder="Message Marketing Eve..."
          disabled={isLoading || parentIsLoading}
        />
        <button
          type="submit"
          disabled={isLoading || parentIsLoading || !query.trim()}
          className="absolute right-2 rounded-lg p-2 text-gray-500 hover:bg-gray-100 disabled:hover:bg-transparent disabled:opacity-40"
        >
          {(isLoading || parentIsLoading) ? (
            <LoadingSpinner size={20} className="text-primary-500" />
          ) : (
            <Send className="h-5 w-5" />
          )}
        </button>
      </div>
      {error && (
        <p className="absolute -top-6 left-0 text-sm text-red-500">{error}</p>
      )}
    </form>
  );
}