import React, { useState, useCallback } from 'react';
import Answer from './content/Answer';
import QuestionButton from './questions/QuestionButton';
import { getCompletion } from '../services/openai';
import { getErrorMessage } from '../utils/errors';

const questions = [
  'What are the best KOL marketing strategies on Xiaohongshu?',
  'How to create engaging content for Xiaohongshu?',
  'What are the costs of advertising on Xiaohongshu?',
  'How to measure ROI on Xiaohongshu marketing?',
  'What are the requirements for opening a brand account?'
];

interface RelatedQuestionsProps {
  onAskQuestion: (question: string) => void;
}

export default function RelatedQuestions({ onAskQuestion }: RelatedQuestionsProps) {
  const [selectedQuestion, setSelectedQuestion] = useState<string | null>(null);
  const [loadingQuestions, setLoadingQuestions] = useState<Set<string>>(new Set());
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);

  const handleQuestionClick = useCallback(async (question: string) => {
    if (loadingQuestions.has(question)) return;
    
    setLoadingQuestions(prev => new Set(prev).add(question));
    setSelectedQuestion(question);
    setError(null);

    if (answers[question]) {
      setLoadingQuestions(prev => {
        const next = new Set(prev);
        next.delete(question);
        return next;
      });
      return;
    }

    try {
      const response = await getCompletion(question);
      setAnswers(prev => ({ ...prev, [question]: response }));
      onAskQuestion(question);
    } catch (err) {
      setError(getErrorMessage(err));
      console.error('Error fetching answer:', err);
    } finally {
      setLoadingQuestions(prev => {
        const next = new Set(prev);
        next.delete(question);
        return next;
      });
    }
  }, [answers, loadingQuestions, onAskQuestion]);

  return (
    <div className="space-y-4">
      <div className="bg-white border border-primary-100 rounded-xl p-4 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-800 mb-3">Related</h2>
        <div className="space-y-2">
          {questions.map((question) => (
            <QuestionButton
              key={question}
              question={question}
              isLoading={loadingQuestions.has(question)}
              isSelected={selectedQuestion === question}
              onClick={() => handleQuestionClick(question)}
            />
          ))}
        </div>
      </div>

      {error && (
        <div className="bg-white border border-red-200 rounded-xl p-6 shadow-sm">
          <p className="text-red-500">{error}</p>
        </div>
      )}

      {selectedQuestion && answers[selectedQuestion] && (
        <div className="bg-white border border-primary-100 rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">{selectedQuestion}</h3>
          <Answer content={answers[selectedQuestion]} />
        </div>
      )}
    </div>
  );
}