import React from 'react';
import { Library } from 'lucide-react';
import LibraryItem from './LibraryItem';

const libraryItems = [
  {
    title: 'Top KOL marketing trends on Xiaohongshu',
    category: 'Marketing',
    date: '2d ago'
  },
  {
    title: 'Creating viral content strategies for Xiaohongshu',
    category: 'Content',
    date: '3d ago'
  },
  {
    title: 'Xiaohongshu advertising costs and ROI analysis',
    category: 'Analytics',
    date: '4d ago'
  },
  {
    title: 'Best practices for brand accounts on Xiaohongshu',
    category: 'Branding',
    date: '5d ago'
  },
  {
    title: 'Engagement metrics for Xiaohongshu campaigns',
    category: 'Analytics',
    date: '1w ago'
  },
  {
    title: 'Product launch strategies on Xiaohongshu',
    category: 'Strategy',
    date: '1w ago'
  }
];

export default function LibrarySection() {
  return (
    <div className="pt-4">
      <div className="flex items-center gap-3 text-gray-600 px-2 py-2">
        <Library size={18} className="text-primary-500" />
        <span>Xiaohongshu Library</span>
      </div>
      <div className="mt-2 space-y-1">
        {libraryItems.map((item, index) => (
          <LibraryItem
            key={index}
            title={item.title}
            category={item.category}
            date={item.date}
          />
        ))}
      </div>
    </div>
  );
}