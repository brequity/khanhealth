import React from 'react';
import { Clock } from 'lucide-react';

interface LibraryItemProps {
  title: string;
  category: string;
  date: string;
}

export default function LibraryItem({ title, category, date }: LibraryItemProps) {
  return (
    <a 
      href="#"
      className="w-full flex items-center gap-2 text-gray-500 hover:text-primary-600 px-2 py-1.5 rounded-lg hover:bg-primary-50 text-left text-sm transition-colors cursor-pointer"
    >
      <Clock size={14} />
      <div className="flex-1 truncate">
        <span className="mr-2">{title}</span>
        <span className="text-xs text-gray-400">· {category}</span>
      </div>
      <span className="text-xs text-gray-400">{date}</span>
    </a>
  );
}