import React from 'react';
import RelatedQuestions from './RelatedQuestions';
import Answer from './content/Answer';
import ActionBar from './content/ActionBar';
import WelcomeMessage from './WelcomeMessage';
import LoadingSpinner from './ui/LoadingSpinner';

interface MainContentProps {
  response: string | null;
  error: string | null;
  onAskQuestion: (question: string) => void;
  isLoading: boolean;
}

export default function MainContent({ response, error, onAskQuestion, isLoading }: MainContentProps) {
  return (
    <div className="max-w-3xl mx-auto">
      <div className="space-y-6 mb-6">
        {isLoading && (
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex justify-center items-center py-12">
              <LoadingSpinner size={32} className="text-primary-500" />
            </div>
          </div>
        )}
        {error && !isLoading && (
          <div className="bg-white rounded-lg border border-red-200 p-6">
            <p className="text-red-500">{error}</p>
          </div>
        )}
        {response && !isLoading && (
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <Answer content={response} />
            <ActionBar />
          </div>
        )}
        {!response && !error && !isLoading && (
          <WelcomeMessage onAskQuestion={onAskQuestion} />
        )}
      </div>
      <RelatedQuestions onAskQuestion={onAskQuestion} />
    </div>
  );
}