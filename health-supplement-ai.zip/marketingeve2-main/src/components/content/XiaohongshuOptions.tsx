import React from 'react';
import ContentSection from './ContentSection';
import ListItem from './ListItem';

const marketingChannels = [
  {
    title: 'Official Advertising Platform (广告主平台)',
    items: [
      'Feed Ads in user\'s homepage',
      'Search result advertisements',
      'KOL collaboration opportunities'
    ]
  },
  {
    title: 'Brand Account (品牌号)',
    items: [
      'Verified brand presence',
      'Enhanced analytics and insights',
      'Direct customer engagement'
    ]
  }
];

const influencerOptions = [
  {
    title: 'KOL Partnerships',
    items: [
      'Micro-influencers (10k-100k followers)',
      'Mid-tier influencers (100k-500k followers)',
      'Top-tier influencers (500k+ followers)'
    ]
  },
  {
    title: 'Content Collaboration',
    items: [
      'Product reviews and unboxing',
      'Lifestyle integration',
      'Tutorial and how-to content'
    ]
  }
];

const ecommerceOptions = [
  {
    title: 'RED Store (小红书商城)',
    items: [
      'Direct product listings',
      'Integration with content',
      'Shopping tags in posts'
    ]
  }
];

export default function XiaohongshuOptions() {
  return (
    <div className="space-y-6">
      <p className="text-gray-700 leading-relaxed">
        Xiaohongshu (小红书) offers several marketing and promotion options. Here are the key opportunities available:
      </p>
      
      <ContentSection title="Official Marketing Channels">
        <ul className="space-y-4">
          {marketingChannels.map((channel, index) => (
            <ListItem key={index} title={channel.title} items={channel.items} />
          ))}
        </ul>
      </ContentSection>

      <ContentSection title="Influencer Marketing">
        <ul className="space-y-4">
          {influencerOptions.map((option, index) => (
            <ListItem key={index} title={option.title} items={option.items} />
          ))}
        </ul>
      </ContentSection>

      <ContentSection title="E-commerce Integration">
        <ul className="space-y-4">
          {ecommerceOptions.map((option, index) => (
            <ListItem key={index} title={option.title} items={option.items} />
          ))}
        </ul>
      </ContentSection>
    </div>
  );
}