import React from 'react';
import ReactMarkdown from 'react-markdown';
import TypingEffect from '../TypingEffect';

interface AnswerProps {
  content: React.ReactNode | string;
}

export default function Answer({ content }: AnswerProps) {
  return (
    <div className="prose dark:prose-invert max-w-none">
      {typeof content === 'string' ? (
        <TypingEffect text={content} />
      ) : (
        content
      )}
    </div>
  );
}