import React from 'react';

interface ListItemProps {
  title: string;
  items?: string[];
}

export default function ListItem({ title, items }: ListItemProps) {
  return (
    <li className="space-y-2">
      <h3 className="font-medium text-gray-900">{title}</h3>
      {items && items.length > 0 && (
        <ul className="list-disc pl-5 space-y-1">
          {items.map((item, index) => (
            <li key={index} className="text-gray-700">{item}</li>
          ))}
        </ul>
      )}
    </li>
  );
}