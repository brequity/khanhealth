import React from 'react';
import { MessageCircle, Share2, Copy, MoreHorizontal } from 'lucide-react';

export default function ActionBar() {
  return (
    <div className="flex items-center gap-4 mt-6">
      <button className="text-gray-500 hover:text-primary-600 flex items-center gap-2 transition-colors">
        <MessageCircle size={18} />
        <span className="text-sm">Follow-up</span>
      </button>
      <button className="text-gray-500 hover:text-primary-600 flex items-center gap-2 transition-colors">
        <Share2 size={18} />
      </button>
      <button className="text-gray-500 hover:text-primary-600 flex items-center gap-2 transition-colors">
        <Copy size={18} />
      </button>
      <button className="text-gray-500 hover:text-primary-600 ml-auto transition-colors">
        <MoreHorizontal size={18} />
      </button>
    </div>
  );
}