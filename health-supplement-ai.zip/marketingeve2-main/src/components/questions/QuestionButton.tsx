import React from 'react';
import { Plus } from 'lucide-react';
import LoadingSpinner from '../ui/LoadingSpinner';

interface QuestionButtonProps {
  question: string;
  isLoading: boolean;
  isSelected: boolean;
  onClick: () => void;
}

export default function QuestionButton({ 
  question, 
  isLoading, 
  isSelected,
  onClick 
}: QuestionButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={isLoading}
      className={`
        w-full flex items-center justify-between p-3 rounded-lg
        text-left group transition-colors
        ${isSelected ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-primary-50'}
        ${isLoading ? 'cursor-wait opacity-75' : 'cursor-pointer'}
      `}
    >
      <span className={`text-sm ${isSelected ? 'text-primary-600' : 'text-gray-700 group-hover:text-primary-600'}`}>
        {question}
      </span>
      <div className="flex-shrink-0">
        {isLoading ? (
          <LoadingSpinner size={16} className="text-primary-500" />
        ) : (
          <Plus size={16} className={`${isSelected ? 'text-primary-600' : 'text-gray-400 group-hover:text-primary-600'}`} />
        )}
      </div>
    </button>
  );
}