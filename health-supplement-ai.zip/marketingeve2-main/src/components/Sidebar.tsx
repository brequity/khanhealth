import React from 'react';
import { Home, Compass, Command, Settings, Menu, X } from 'lucide-react';
import ThemeToggle from './ThemeToggle';
import LibrarySection from './library/LibrarySection';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  onHomeClick: () => void;
}

const Sidebar = ({ isOpen, onToggle, onHomeClick }: SidebarProps) => {
  const handleTabClick = (tab: string) => {
    // Handle tab navigation here
    console.log(`Navigating to ${tab}`);
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={onToggle}
        />
      )}
      
      {/* Mobile toggle button */}
      <button
        onClick={onToggle}
        className="fixed top-4 left-4 z-30 lg:hidden bg-white p-2 rounded-lg shadow-md"
        aria-label="Toggle menu"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <div className={`
        fixed lg:static w-64 bg-white border-r border-primary-100 h-screen p-4 
        flex flex-col transition-all duration-300 ease-in-out z-30
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-primary-600 rounded-sm flex items-center justify-center">
              <span className="text-white font-bold text-sm">M</span>
            </div>
            <span className="text-gray-900 font-semibold">Marketing Eve</span>
          </div>
          <ThemeToggle />
        </div>

        <button className="flex items-center gap-2 bg-primary-50 text-primary-700 px-3 py-2 rounded-lg mb-6 hover:bg-primary-100 transition-colors">
          <span>New Thread</span>
          <div className="flex items-center gap-1 ml-auto">
            <kbd className="px-1.5 py-0.5 text-xs bg-white rounded border border-primary-200">⌘</kbd>
            <kbd className="px-1.5 py-0.5 text-xs bg-white rounded border border-primary-200">N</kbd>
          </div>
        </button>

        <nav className="space-y-1">
          <button 
            onClick={onHomeClick}
            className="w-full flex items-center gap-3 text-gray-600 hover:text-primary-600 px-2 py-2 rounded-lg hover:bg-primary-50 transition-colors"
          >
            <Home size={18} />
            <span>Home</span>
          </button>
          <button 
            onClick={() => handleTabClick('discover')}
            className="w-full flex items-center gap-3 text-gray-600 hover:text-primary-600 px-2 py-2 rounded-lg hover:bg-primary-50 transition-colors"
          >
            <Compass size={18} />
            <span>Discover</span>
          </button>
          <LibrarySection />
        </nav>

        <div className="mt-auto space-y-4">
          <div className="flex items-center gap-2 text-gray-500 px-2 py-2">
            <Command size={16} />
            <span className="text-sm">Shortcuts</span>
          </div>

          <div className="flex items-center justify-between px-2 py-2">
            <div className="flex items-center gap-2">
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=faces"
                alt="Profile"
                className="w-8 h-8 rounded-full"
              />
              <div className="flex flex-col">
                <span className="text-sm text-gray-900">melvindave</span>
                <span className="text-xs text-primary-500">Pro</span>
              </div>
            </div>
            <button 
              onClick={() => handleTabClick('settings')}
              className="text-gray-500 hover:text-primary-600 transition-colors"
            >
              <Settings size={16} />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;