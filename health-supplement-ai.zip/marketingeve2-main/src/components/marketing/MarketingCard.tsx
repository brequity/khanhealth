import React from 'react';
import { ChevronRight } from 'lucide-react';

interface MarketingCardProps {
  title: string;
  description: string;
  onClick: () => void;
}

export default function MarketingCard({ title, description, onClick }: MarketingCardProps) {
  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    onClick();
  };

  return (
    <button
      onClick={handleClick}
      className="w-full p-4 rounded-lg border border-gray-200 bg-white text-left hover:border-primary-200 hover:shadow-md transition-all group cursor-pointer"
    >
      <div className="flex justify-between items-start gap-4">
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-gray-900 mb-2 group-hover:text-primary-600 truncate">{title}</h3>
          <p className="text-gray-600 text-sm line-clamp-2">{description}</p>
        </div>
        <ChevronRight className="w-5 h-5 flex-shrink-0 text-gray-400 group-hover:text-primary-500 transition-colors" />
      </div>
    </button>
  );
}