export const marketingCards = [
  {
    id: 'content-strategy',
    title: 'Content Strategy',
    description: 'Get help with creating engaging content that resonates with Xiaohongshu users',
    query: 'What are the best content strategies for Xiaohongshu? Include tips for post formats, timing, and engagement.'
  },
  {
    id: 'kol-collaboration',
    title: 'KOL Collaboration',
    description: 'Learn about influencer partnerships and campaign strategies',
    query: 'How to effectively work with KOLs on Xiaohongshu? Include collaboration strategies and best practices.'
  },
  {
    id: 'analytics-roi',
    title: 'Analytics & ROI',
    description: 'Understand performance metrics and measure campaign success',
    query: 'What are the key metrics to track for Xiaohongshu marketing success? Include ROI measurement techniques.'
  },
  {
    id: 'brand-growth',
    title: 'Brand Growth',
    description: 'Develop strategies to increase brand awareness and engagement',
    query: 'What are effective brand growth strategies for Xiaohongshu? Include tips for increasing visibility and engagement.'
  }
];