import { APIError } from '../utils/errors';
import { env } from '../utils/env';

interface ChatMessage {
  role: 'user' | 'system' | 'assistant';
  content: string;
}

export async function callOpenAI(messages: ChatMessage[]) {
  const API_KEY = env.OPENAI_API_KEY;

  if (!API_KEY) {
    throw new APIError('OpenAI API key is not configured');
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages,
        temperature: 0.7,
        max_tokens: 2048
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new APIError(error.error?.message || `API Error: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    if (error instanceof APIError) {
      throw error;
    }
    throw new APIError('Failed to communicate with OpenAI API');
  }
}