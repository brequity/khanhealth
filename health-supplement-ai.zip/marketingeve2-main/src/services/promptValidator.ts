import { marketingKeywords, marketingTopics } from '../utils/marketingConstants';

export function isMarketingRelated(prompt: string): { isValid: boolean; reason?: string } {
  const lowercasePrompt = prompt.toLowerCase();

  // Check if the prompt contains marketing-related keywords
  const hasKeywords = marketingKeywords.some(keyword => 
    lowercasePrompt.includes(keyword.toLowerCase())
  );

  // Check if the prompt is about marketing topics
  const hasTopics = marketingTopics.some(topic => 
    lowercasePrompt.includes(topic.toLowerCase())
  );

  // Always allow Xiaohongshu-related questions
  const isXiaohongshuRelated = lowercasePrompt.includes('xiaohongshu') || 
                              lowercasePrompt.includes('小红书') ||
                              lowercasePrompt.includes('red book');

  if (isXiaohongshuRelated || hasKeywords || hasTopics) {
    return { isValid: true };
  }

  return {
    isValid: false,
    reason: "Please ask questions about Xiaohongshu (小红书) marketing, Chinese social media, or related business topics."
  };
}