import { callOpenAI } from './api';
import { isMarketingRelated } from './promptValidator';
import { APIError } from '../utils/errors';

export async function getCompletion(prompt: string) {
  const validation = isMarketingRelated(prompt);
  if (!validation.isValid) {
    throw new APIError(validation.reason || 'Invalid prompt');
  }

  const messages = [
    {
      role: 'system' as const,
      content: 'You are a marketing assistant specializing in Xiaohongshu (小红书) marketing. Provide detailed, actionable advice about marketing strategies, content creation, and business growth on the platform.'
    },
    {
      role: 'user' as const,
      content: prompt
    }
  ];

  return callOpenAI(messages);
}